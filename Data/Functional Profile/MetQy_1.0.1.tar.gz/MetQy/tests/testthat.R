library(testthat)
library(MetQy)

test_check("MetQy")
